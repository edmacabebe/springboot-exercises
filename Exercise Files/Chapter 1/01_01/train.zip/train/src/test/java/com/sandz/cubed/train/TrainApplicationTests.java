package com.sandz.cubed.train;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainApplicationTests {

	@Test
	void contextLoads() {
	}

}
